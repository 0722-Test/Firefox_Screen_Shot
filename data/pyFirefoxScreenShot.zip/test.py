if __name__ == '__main__':
    print(1+1)