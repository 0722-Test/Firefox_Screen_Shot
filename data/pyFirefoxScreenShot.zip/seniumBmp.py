﻿from selenium import webdriver
from PIL import Image
import time

# url='https://cn.bing.com/search?q=pyspark'
# url='file://c:/Users/Administrator/AppData/Local/QuestionTool/tmp/vk-103042012_question.html'
# url='file://c:/Users/Administrator/AppData/Local/QuestionTool/tmp/vk-103042012_answer.html'
url='file://e:/data/ZB-39029_answer.html'
# option=webdriver.ChromeOptions()
# option=webdriver.FirefoxOptions()
# option.add_argument('headless')

option = webdriver.FirefoxOptions()
option.add_argument('-headless')

# driver=webdriver.Chrome(options=option)
driver=webdriver.Firefox(options=option)

driver.get(url)
# width = driver.execute_script("return document.documentElement.scrollWidth")
# height = driver.execute_script("return document.documentElement.scrollHeight")
# driver.set_window_size(width,height) #修改浏览器窗口大小
driver.set_window_size(272, 6000)


# driver.execute_script("""
#               (function () {
#                   var y = 0;
#                   var step = 100;
#                   window.scroll(0, 0);
#                   function f() {
#                       if (y < document.body.scrollHeight) {
#                           y += step;
#                           window.scroll(0, y);
#                           setTimeout(f, 100);
#                       } else {
#                           window.scroll(0, 0);
#                           document.title += "scroll-done";
#                       }
#                   }
#                   setTimeout(f, 1000);
#               })();
#           """)
#
# for i in range(4000):
#     # print(browser.title)
#     if "scroll-done" in driver.title:
#         print(i)
#         print(':::browser srcoll done bottom')
#         break
#     time.sleep(0.3)
# time.sleep(0.2)
# time.sleep(0.1)
#获取整个网页截图

# size=driver.get_window_size()

driver.get_screenshot_as_file('webpage1.png')
# print("整个网页尺寸:height={},width={}".format(height,width))
# im=Image.open('webpage1.png')
# print("截图尺寸:height={},width={}".format(im.size[1],im.size[0]))
