﻿import os
from PIL import Image
import cv2
import numpy as np
import shutil

def splitimage(src, rownum, colnum, dstpath):
    img = Image.open(src)
    w, h = img.size
    if rownum <= h and colnum <= w:
        s = os.path.split(src)
        if dstpath == '':
            dstpath = s[0]
        fn = s[1].split('.')
        basename = fn[0]
        ext = fn[-1]
        num = 0
        rowheight = h // rownum
        colwidth = w // colnum
        for r in range(rownum):
            for c in range(colnum):
                box = (c * colwidth, r * rowheight, (c + 1) * colwidth, (r + 1) * rowheight)
                img.crop(box).save(os.path.join(dstpath, basename + '_' + str(num) + '.' + ext))
                num = num + 1
    else:
        print('不数！')

def splitimageByHeight(src, rowheight, colnum, partname, dstpath, h):
    img = Image.open(src)
    w, hActual = img.size

    rownum = h // rowheight
    if rownum * rowheight < h:
        rownum += 1
    if rowheight <= h and colnum <= w:
        s = os.path.split(src)
        if dstpath == '':
            dstpath = s[0]
        fn = s[1].split('.')
        basename = fn[0]
        ext = fn[-1]
        num = 0
        # rowheight = h // rownum
        colwidth = w // colnum
        for r in range(rownum):
            for c in range(colnum):
                bottom = (r + 1) * rowheight
                if bottom > h:
                    bottom = h
                box = (c * colwidth, r * rowheight, (c + 1) * colwidth, bottom)
                img.crop(box).convert("RGB").save(os.path.join(dstpath, f'{basename}_{partname}00_{num}.{ext}'))
                num = num + 1
    else:
        print('不数！')

def getContinueSpaceH(spaceL,top, bottom):
    startY = bottom
    cnt = 1
    while startY - cnt > top:
        if startY-cnt in spaceL:
            cnt += 1
        else:
            break
    return cnt

def getPicBottom(startY,rowheight,h,spaceL):
    if startY + rowheight > h:
        return h
    else:
        bottom = startY + rowheight
        while startY < bottom:
            if bottom in spaceL:
                break
            else:
                bottom -= 1
    if startY < bottom:
        continueSpaceH = getContinueSpaceH(spaceL,startY, bottom)
        return bottom - continueSpaceH // 2
    else:
        print(f"check: start={startY},bottom={bottom}")

def getBothSpace(pdf, line):
    rowData = pdf[line]
    start = 0
    end = 0
    for data in rowData:
        if data == 0:
            start += 1
        else:
            break
    # for data in rowData[::-1]:
    #     if data == 0:
    #         end += 1
    #     else:
    #         break
    return start, end
    # print(rowData)
    # pass

def similarity(arr, start, maxOffset=18):
    first = arr[start]
    for i in range(start+1,len(arr)):
        if abs(arr[i] - first) > maxOffset:
            return i
    else:
        return len(arr)


def getPicBottom2(pdf, startY, screenHeight, bmpHeight, rowHeight,spaceL):
    if startY + screenHeight >= bmpHeight:
        return bmpHeight
    else:
        cnt = -1
        maxSpace = {'x':0,'idx':0}
        bottom = startY + screenHeight
        for _ in range(min(bottom,28)):
            if bottom in spaceL:
                maxSpace['x'] = -1
                maxSpace['idx'] = bottom
                cnt = 3
                break
            else:
                x,y=getBothSpace(pdf, bottom)
                if maxSpace.get('x') == 0:
                    maxSpace['x'] = x
                    maxSpace['idx'] = bottom
                    cnt = 0
                elif x - maxSpace.get('x') > 20:
                    maxSpace['x'] = x
                    maxSpace['idx'] = bottom
                    cnt = 0
                elif cnt != -1 and abs(x - maxSpace.get('x')) < 18:
                    cnt += 1
                elif maxSpace.get('x') - x > 20:
                    break
                bottom -= 1
        else:
            print("end")
            pass

    '''
    # 中间碰到了空行
    if len(startSpace) < rowHeight:
        if startY < bottom:
            continueSpaceH = getContinueSpaceH(spaceL,startY, bottom)
            return bottom - continueSpaceH // 2
        else:
            print(f"check: start={startY},bottom={bottom}")
    else:
        firstSame = similarity(startSpace,0)
        spaceCnt = similarity(startSpace,firstSame)
        continueSpaceH = spaceCnt - firstSame
        return startY + screenHeight - continueSpaceH // 2
    '''
    return maxSpace.get('idx') - cnt // 2

def splitImageBySplitPosion(inputFile, posiLst,partname,screenHeight):
    # global destPath
    img = Image.open(inputFile)

    colwidth, hActual = img.size
    s = os.path.split(inputFile)
    # if destPath == '':
    #     destPath = s[0]
    destPath = s[0].replace('ques_photo', 'ques_photo_split')
    if not os.path.exists(destPath):
        os.makedirs(destPath)
    fn = s[1].split('.')
    basename = fn[0]
    ext = fn[-1]
    for num in range(len(posiLst)-1):
        startY = posiLst[num]+1
        bottom = posiLst[num+1]
        box = (0, startY, colwidth, bottom)
        if bottom - startY ==  screenHeight:
            img.crop(box).convert('RGB').save(os.path.join(destPath, f'{basename}_{partname}_{num}.{ext}'))
        else:
            newImage = Image.new('RGB',(colwidth,screenHeight),(255,255,255))
            newImage.paste(img.crop(box).convert('RGB'),(0,0))
            newImage.save(os.path.join(destPath, f'{basename}_{partname}_{num}.{ext}'))
            pass
        # img.crop(box).save(os.path.join(destPath, f'{basename}_{partname}_{num}.{ext}'))

def splitimageByHeightWithSpace(src, rowheight, partname, dstpath,spaceL,h):
    img = Image.open(src)
    colwidth, hActual = img.size
    s = os.path.split(src)
    if dstpath == '':
        dstpath = s[0]
    fn = s[1].split('.')
    basename = fn[0]
    ext = fn[-1]
    num = 0
    if rowheight <= h:
        startY = 0
        while startY < h:
            # pdf, startY, screenHeight, bmpHeight, rowHeight):
            bottom = getPicBottom(startY, screenheight, h, slLst)

            box = (0, startY, colwidth, bottom)
            img.crop(box).convert('RGB').save(os.path.join(dstpath, f'{basename}_{partname}_{num}.{ext}'))
            startY = bottom+1
            num += 1
    else:
        img.save(os.path.join(dstpath, f'{basename}_{partname}_{num}.{ext}'))
        print('不分割！')

def findSpaceLine(picFile):
    Grayimg = cv2.imread(picFile, cv2.IMREAD_GRAYSCALE)
    ret, thresh = cv2.threshold(Grayimg, 240, 255, cv2.THRESH_BINARY_INV)
    np.set_printoptions(threshold=np.inf)
    np.set_printoptions(linewidth=800)
    # print(thresh)
    # with open(picFile + '_png.txt', 'wt', encoding='utf-8') as f:
        # ss = str(thresh)
    xx = thresh.any(axis=1)
    yy = np.where(xx == 0)[0]

    # f.write(ss.replace('255', '1').replace('  0', '0'))
    # pass
    return yy

def findSplitPosition(picFile,screenHeight,rowHeight=18):
    Grayimg = cv2.imread(picFile, cv2.IMREAD_GRAYSCALE)
    ret, thresh = cv2.threshold(Grayimg, 240, 255, cv2.THRESH_BINARY_INV)
    np.set_printoptions(threshold=np.inf)
    np.set_printoptions(linewidth=800)
    # print(thresh)
    # with open(picFile + '_png.txt', 'wt', encoding='utf-8') as f:
        # ss = str(thresh)
    xx = thresh.any(axis=1)
    yy = np.where(xx == 0)[0]

    # 删除图片尾部空白：，计算出图片的想要的高度
    slLst = list(yy)
    slLst.reverse()
    if len(slLst):
        maxHeight = slLst[0] + 1
        for h in slLst:
            if maxHeight - 1 == h:
                maxHeight -= 1
            else:
                break
        if slLst[0] - maxHeight > 3:
            maxHeight += 3
    else:
        maxHeight = thresh.shape[0]

    splitPosi = [-1]
    if screenHeight <= maxHeight:
        startY = 0
        while startY < maxHeight:
            bottom = getPicBottom2(thresh, startY, screenHeight, maxHeight, rowHeight, slLst)
            splitPosi.append(bottom)
            startY = bottom+1
    else:
        splitPosi.append(maxHeight)
        pass

    # f.write(ss.replace('255', '1').replace('  0', '0'))
    # pass
    return splitPosi

# import pandas_datareader as pdr
# from datetime import datetime
# start=datetime(2019,12,1)
# end =datetime.today()
# alibaba=pdr.data.get_data_yahoo('BABA',start,end)
# alibaba=pdr.get_da('BABA',start,end)
# pd.get

configOne = {'h':170,'n':'h19'}
destPath = r"g:\ques_photo_split"
def procMain(path, deepLevel):
    global destPath
    global configOne
    deepLevel += 1

    rootdir = path
    dirList = os.listdir(path)  # 列出文件夹下所有的目录与文件
    for i in range(0, len(dirList)):
        com_path = os.path.join(rootdir, dirList[i])
        if os.path.isdir(com_path):
            procMain(com_path,deepLevel)
        else:
            if com_path.endswith('.jpg'):
                print(com_path)
                posiLst = findSplitPosition(com_path, configOne.get('h'))
                splitImageBySplitPosion(com_path, posiLst, configOne.get('n'),configOne.get('h'))


if __name__=='__main__':
    # 1.9寸的width*height是 272*170
    # 2.2寸的width*height是 406*190
    # inch19 = (272, 170)
    # inch22 = (406, 190)
    twoSize = [{'w':272,'h':170,'n':'h19'}]#,{'h':190,'n':'h22'}]
    # inputFile = r"e:\photo\ffa2545ee56c43d6b8c989d48f1be6b0.jpg"
    # inputFile = r"e:\photo\ques\ZB-19807_question.jpg"
    inputFile = r"e:\photo\ques\ZB-13312_question.jpg"
    inputFile = r"g:\ques_photo\1\10\vk-10304100c_question.jpg"
    inputFile = r"g:\ques_photo\1\10\vk-103042012_question.jpg"
    inputFile = r"g:\ques_photo\2\10\ZB-26762_answer.jpg"
    inputFile = r"g:\ques_photo\1\10\vk-103248008_question.jpg"
    inputFile = r"e:\data\xl.jpg"
    # ZB-28727_answer
    # inputFile = r"e:\photo\ques\ZB-830_answer.jpg"
    # destPath = r"e:\photo\print"
    '''
    sl = findSpaceLine(inputFile)
    slLst = list(sl)
    slLst.reverse()
    maxHeight = slLst[0] + 1
    for h in slLst:
        if maxHeight - 1 == h:
            maxHeight -= 1
        else:
            break
    if slLst[0] - maxHeight > 3:
        maxHeight += 3
    # if True:
    #     for one in twoSize:
    #         splitimageByHeight(inputFile,one.get('h'),1,one.get('n'), destPath, maxHeight)
    '''
    # procMain(r'g:\ques_photo', 0)
    test = 1
    if test:
        posiLst = findSplitPosition(inputFile, configOne.get('h'))
        splitImageBySplitPosion(inputFile, posiLst, configOne.get('n'),configOne.get('h'))
    else:
        procMain(r'g:\ques_photo', 0)
        # posiLst = findSplitPosition(com_path, configOne.get('h'))
        # splitImageBySplitPosion(com_path, posiLst, configOne.get('n'))
        # splitimageByHeightWithSpace(inputFile,one.get('h'),one.get('n'), destPath,sl,maxHeight)